<?php
/**
 * Global business/contact settings.
 *
 * @package ZAEC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function zaec_options_defaults() {
	return array(
		'phone_display' => '099 123 4567',
		'phone_raw'     => '+385991234567',
		'email'         => 'info@zaec.hr',
		'location'      => 'Osijek · Hrvatska',
		'address'       => 'Čvrsnička 29a',
		'city'          => 'Osijek',
		'country_code'  => 'HR',
		'hours'         => 'pon–pet · 9–17 h',
		'legal_name'    => 'ZAEC, obrt za računalne djelatnosti, vl. Filip Zajec',
		'latitude'      => '45.5550',
		'longitude'     => '18.6955',
		'price_range'   => '240€ - 1490€',
		'privacy_url'   => '',
		'terms_url'     => '',
		'form_recipient'=> get_option( 'admin_email' ),
	);
}

function zaec_get_options() {
	return wp_parse_args( get_option( 'zaec_options', array() ), zaec_options_defaults() );
}

function zaec_register_options() {
	register_setting(
		'zaec_options_group',
		'zaec_options',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'zaec_sanitize_options',
			'default'           => zaec_options_defaults(),
		)
	);
}
add_action( 'admin_init', 'zaec_register_options' );

function zaec_sanitize_options( $input ) {
	$defaults = zaec_options_defaults();
	$output   = array();
	foreach ( $defaults as $key => $default ) {
		$value = isset( $input[ $key ] ) ? $input[ $key ] : '';
		if ( in_array( $key, array( 'email', 'form_recipient' ), true ) ) {
			$output[ $key ] = sanitize_email( $value );
		} elseif ( in_array( $key, array( 'privacy_url', 'terms_url' ), true ) ) {
			$output[ $key ] = esc_url_raw( $value );
		} else {
			$output[ $key ] = sanitize_text_field( $value );
		}
	}
	return $output;
}

function zaec_options_menu() {
	add_theme_page(
		__( 'ZAEC postavke', 'zaec' ),
		__( 'ZAEC postavke', 'zaec' ),
		'edit_theme_options',
		'zaec-options',
		'zaec_render_options_page'
	);
}
add_action( 'admin_menu', 'zaec_options_menu' );

function zaec_render_options_page() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}
	$options = zaec_get_options();
	$fields  = array(
		'phone_display'  => array( 'label' => 'Telefon — prikaz', 'type' => 'text' ),
		'phone_raw'      => array( 'label' => 'Telefon — međunarodni format', 'type' => 'text', 'help' => 'Primjer: +385991234567' ),
		'email'          => array( 'label' => 'Javni email', 'type' => 'email' ),
		'location'       => array( 'label' => 'Lokacija — kratki prikaz', 'type' => 'text' ),
		'address'        => array( 'label' => 'Ulica i kućni broj', 'type' => 'text' ),
		'city'           => array( 'label' => 'Grad', 'type' => 'text' ),
		'country_code'   => array( 'label' => 'ISO oznaka države', 'type' => 'text', 'help' => 'Primjer: HR' ),
		'hours'          => array( 'label' => 'Radno vrijeme', 'type' => 'text' ),
		'legal_name'     => array( 'label' => 'Pravni naziv', 'type' => 'text' ),
		'latitude'       => array( 'label' => 'Latitude', 'type' => 'text' ),
		'longitude'      => array( 'label' => 'Longitude', 'type' => 'text' ),
		'price_range'    => array( 'label' => 'Raspon cijena za schema markup', 'type' => 'text' ),
		'form_recipient' => array( 'label' => 'Email za upite s forme', 'type' => 'email' ),
		'privacy_url'    => array( 'label' => 'URL stranice privatnosti', 'type' => 'url' ),
		'terms_url'      => array( 'label' => 'URL uvjeta korištenja', 'type' => 'url' ),
	);
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'ZAEC — globalni podaci', 'zaec' ); ?></h1>
		<p><?php esc_html_e( 'Ovdje se uređuju podaci koji se koriste u headeru, footeru, kontakt sekciji, formi i structured data outputu.', 'zaec' ); ?></p>
		<form action="options.php" method="post">
			<?php settings_fields( 'zaec_options_group' ); ?>
			<table class="form-table" role="presentation">
				<?php foreach ( $fields as $key => $field ) : ?>
					<tr>
						<th scope="row"><label for="zaec-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field['label'] ); ?></label></th>
						<td>
							<input class="regular-text" id="zaec-<?php echo esc_attr( $key ); ?>" type="<?php echo esc_attr( $field['type'] ); ?>" name="zaec_options[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( isset( $options[ $key ] ) ? $options[ $key ] : '' ); ?>">
							<?php if ( ! empty( $field['help'] ) ) : ?><p class="description"><?php echo esc_html( $field['help'] ); ?></p><?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}
