<?php
/**
 * Production inquiry form handler.
 *
 * @package ZAEC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function zaec_handle_inquiry() {
	$is_ajax = isset( $_POST['zaec_ajax'] ) && '1' === sanitize_text_field( wp_unslash( $_POST['zaec_ajax'] ) );
	$fail = static function ( $message, $status = 400 ) use ( $is_ajax ) {
		if ( $is_ajax ) {
			wp_send_json_error( array( 'message' => $message ), $status );
		}
		$url = add_query_arg( 'zaec_form', 'error', home_url( '/#upit' ) );
		wp_safe_redirect( $url );
		exit;
	};

	if ( ! isset( $_POST['zaec_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['zaec_nonce'] ) ), 'zaec_inquiry' ) ) {
		$fail( __( 'Sigurnosna provjera nije prošla. Osvježite stranicu i pokušajte ponovno.', 'zaec' ), 403 );
	}

	$honeypot = isset( $_POST['website'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['website'] ) ) ) : '';
	if ( '' !== $honeypot ) {
		$fail( __( 'Upit nije prihvaćen.', 'zaec' ), 400 );
	}

	$started = isset( $_POST['started_at'] ) ? absint( $_POST['started_at'] ) : 0;
	if ( $started && ( time() - $started ) < 2 ) {
		$fail( __( 'Upit je poslan prebrzo. Pokušajte ponovno.', 'zaec' ), 429 );
	}

	$ip        = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
	$rate_key  = 'zaec_form_' . md5( wp_salt( 'nonce' ) . $ip );
	$rate_count = (int) get_transient( $rate_key );
	if ( $rate_count >= 5 ) {
		$fail( __( 'Previše pokušaja u kratkom vremenu. Pokušajte ponovno kasnije.', 'zaec' ), 429 );
	}
	set_transient( $rate_key, $rate_count + 1, 15 * MINUTE_IN_SECONDS );

	$name     = isset( $_POST['ime'] ) ? sanitize_text_field( wp_unslash( $_POST['ime'] ) ) : '';
	$contact  = isset( $_POST['kontakt'] ) ? sanitize_text_field( wp_unslash( $_POST['kontakt'] ) ) : '';
	$activity = isset( $_POST['djelatnost'] ) ? sanitize_text_field( wp_unslash( $_POST['djelatnost'] ) ) : '';
	$message  = isset( $_POST['poruka'] ) ? sanitize_textarea_field( wp_unslash( $_POST['poruka'] ) ) : '';
	$package  = isset( $_POST['paket'] ) ? sanitize_text_field( wp_unslash( $_POST['paket'] ) ) : '';

	$valid_email = is_email( $contact );
	$valid_phone = (bool) preg_match( '/^[+0-9][0-9\s\-\/()]{5,}$/', $contact );
	if ( strlen( $name ) < 2 || ! $activity || ( ! $valid_email && ! $valid_phone ) ) {
		$fail( __( 'Provjerite ime, kontakt i djelatnost.', 'zaec' ) );
	}

	$options   = zaec_get_options();
	$recipient = is_email( $options['form_recipient'] ) ? $options['form_recipient'] : get_option( 'admin_email' );
	$subject   = sprintf( '[ZAEC upit] %s — %s', $name, $activity );
	$body      = "Novi upit s web stranice\n\n";
	$body     .= "Ime: {$name}\nKontakt: {$contact}\nDjelatnost: {$activity}\n";
	$body     .= $package ? "Paket: {$package}\n" : '';
	$body     .= $message ? "\nPoruka:\n{$message}\n" : '';
	$body     .= "\nIzvor: " . home_url( '/' ) . "\n";
	$headers   = array( 'Content-Type: text/plain; charset=UTF-8' );
	if ( $valid_email ) {
		$headers[] = 'Reply-To: ' . $name . ' <' . $contact . '>';
	}

	if ( ! wp_mail( $recipient, $subject, $body, $headers ) ) {
		$fail( __( 'Poruka trenutačno nije poslana. Molimo pokušajte ponovno ili nas nazovite.', 'zaec' ), 500 );
	}

	if ( $is_ajax ) {
		wp_send_json_success( array( 'message' => __( 'Upit je stigao.', 'zaec' ) ) );
	}
	wp_safe_redirect( add_query_arg( 'zaec_form', 'sent', home_url( '/#upit' ) ) );
	exit;
}
add_action( 'admin_post_nopriv_zaec_inquiry', 'zaec_handle_inquiry' );
add_action( 'admin_post_zaec_inquiry', 'zaec_handle_inquiry' );
