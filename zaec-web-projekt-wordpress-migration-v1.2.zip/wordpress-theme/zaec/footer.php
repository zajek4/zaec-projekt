<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$options = zaec_get_options();
?>
<footer data-theme="dark" class="site-footer">
<div class="wrap foot-grid">
<div class="foot-col foot-brand"><?php zaec_brand_mark( 'foot-mark' ); ?><p class="foot-tag">ZAEC · Web studio</p><p class="foot-line">Gradimo web za ljude koji grade sve ostalo.</p><p class="foot-loc"><?php echo esc_html($options['location']); ?></p></div>
<div class="foot-col"><p class="foot-h"><?php esc_html_e('Usluge','zaec'); ?></p><a href="<?php echo esc_url(zaec_home_anchor('za-koga')); ?>">Web stranice</a><a href="<?php echo esc_url(zaec_home_anchor('za-koga')); ?>">Webshop</a><a href="<?php echo esc_url(zaec_home_anchor('za-koga')); ?>">Landing page</a><a href="<?php echo esc_url(zaec_home_anchor('za-koga')); ?>">SEO</a><a href="<?php echo esc_url(zaec_home_anchor('za-koga')); ?>">Hosting</a></div>
<div class="foot-col"><p class="foot-h"><?php esc_html_e('Studio','zaec'); ?></p><a href="<?php echo esc_url(zaec_home_anchor('za-koga')); ?>">Za koga radimo</a><a href="<?php echo esc_url(zaec_home_anchor('cijene')); ?>">Cijene</a><a href="<?php echo esc_url(zaec_home_anchor('radovi')); ?>">Radovi</a><a href="<?php echo esc_url(zaec_home_anchor('faq')); ?>">Pitanja</a><a href="<?php echo esc_url(zaec_home_anchor('upit')); ?>">Kontakt</a></div>
<div class="foot-col"><p class="foot-h"><?php esc_html_e('Koordinate','zaec'); ?></p><a href="mailto:<?php echo esc_attr($options['email']); ?>"><?php echo esc_html($options['email']); ?></a><a href="tel:<?php echo esc_attr(zaec_phone_href($options['phone_raw'])); ?>"><?php echo esc_html($options['phone_display']); ?></a><span class="foot-coords"><?php echo esc_html($options['latitude'].'° N · '.$options['longitude'].'° E'); ?></span></div>
</div>
<div class="wrap foot-bottom"><span>© <?php echo esc_html(wp_date('Y')); ?> <?php echo esc_html($options['legal_name']); ?> · <?php echo esc_html($options['location']); ?></span><span class="foot-legal"><?php if($options['terms_url']): ?><a href="<?php echo esc_url($options['terms_url']); ?>">Uvjeti</a><?php endif; ?><?php if($options['privacy_url']): ?><a href="<?php echo esc_url($options['privacy_url']); ?>">Privatnost</a><?php endif; ?></span></div>
<svg class="foot-giant" viewBox="0 0 1200 190" aria-hidden="true"><text x="600" y="160" text-anchor="middle">ZAEC</text></svg>
</footer>
<div id="toast" role="status" aria-live="polite"></div>
<?php if ( is_front_page() ) : ?><script>window.addEventListener('error',function(e){if(e&&e.target&&e.target.tagName==='SCRIPT'&&e.target.type==='module'){document.documentElement.classList.add('no-3d');}},true);setTimeout(function(){if(!window.__ZAEC_3D){document.documentElement.classList.add('no-3d');}},6000);</script><?php endif; ?>
<?php wp_footer(); ?>
</body></html>
