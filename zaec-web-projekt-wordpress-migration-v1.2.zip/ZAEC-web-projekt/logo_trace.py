#!/usr/bin/env python3
"""Trace the real ZAEC logo (white on transparent PNG) -> clean SVG paths."""
import numpy as np
from PIL import Image
import potrace

SRC = "/home/user/uploads/zaec-logo-transparent.png"
OUT_SVG = "/home/user/zaec/assets/zmon-traced.svg"
OUT_PNG = "/home/user/zaec/assets/zmon-traced-preview.png"

im = Image.open(SRC).convert("RGBA")
a = np.asarray(im)
alpha = a[..., 3]
print("size:", im.size, "alpha min/max:", alpha.min(), alpha.max())
if alpha.max() < 250:
    raise SystemExit("no alpha channel")

ink = alpha > 40  # True = ink
ys, xs = np.where(ink)
print("bbox ink: x", xs.min(), xs.max(), " y", ys.min(), ys.max())

bmp = potrace.Bitmap(ink.astype(np.uint32))
path = bmp.trace(turdsize=10, alphamax=1.1, opttolerance=0.28)

def fp(v):
    s = f"{v:.1f}".rstrip("0").rstrip(".")
    return s if s else "0"

parts = []
for curve in path.curves:
    p = curve.start_point
    parts.append(f"M{fp(p.x)} {fp(p.y)}")
    for seg in curve.segments:
        if seg.is_corner:
            parts.append(f"L{fp(seg.c.x)} {fp(seg.c.y)}L{fp(seg.end_point.x)} {fp(seg.end_point.y)}")
        else:
            parts.append(
                f"C{fp(seg.c1.x)} {fp(seg.c1.y)} {fp(seg.c2.x)} {fp(seg.c2.y)} "
                f"{fp(seg.end_point.x)} {fp(seg.end_point.y)}"
            )
    parts.append("Z")
d = "".join(parts)

x0, x1, y0, y1 = xs.min(), xs.max(), ys.min(), ys.max()
W, H = x1 - x0 + 1, y1 - y0 + 1
pad = 0
vb = f"{x0-pad} {y0-pad} {W+2*pad} {H+2*pad}"
print("viewBox:", vb, " aspect:", round(W / H, 3))
print("path bytes:", len(d))

svg = (
    f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{vb}">'
    f'<path d="{d}" fill="currentColor"/></svg>\n'
)
with open(OUT_SVG, "w") as f:
    f.write(svg)

# preview: white on dark + black on paper
prev = (
    f'<svg xmlns="http://www.w3.org/2000/svg" width="900" height="700" viewBox="0 0 900 700">'
    f'<rect width="450" height="700" fill="#0c0d10"/>'
    f'<rect x="450" width="450" height="700" fill="#f4f2ec"/>'
    f'<g transform="translate(60,90) scale({560/W})"><g transform="translate({-x0},{-y0})">'
    f'<path d="{d}" fill="#f4f2ec"/></g></g>'
    f'<g transform="translate(510,90) scale({560/W})"><g transform="translate({-x0},{-y0})">'
    f'<path d="{d}" fill="#17181c"/></g></g></svg>'
)
import cairosvg
cairosvg.svg2png(bytestring=prev.encode(), write_to=OUT_PNG, output_width=900, output_height=700)
print("wrote", OUT_SVG, "and", OUT_PNG)
