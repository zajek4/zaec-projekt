# ZAEC — Landing page

Web studio · Osijek · "Gradimo web za ljude koji grade sve ostalo."

Jedna samostalna stranica (`index.html`) s 3D hologramskom kućom koja se transformira
po djelatnostima, pinned scrollytelling fazama, Three.js + GSAP + Lenis — sve inline,
radi i bez internetske veze.

## Struktura projekta

```
index.html          GOTOVA stranica — build rezultat (sve inline: fontovi, CSS, JS, 3D)
src/
  template.html     HTML predložak s tokenima (__INLINE_*__) 
  styles.css        svi stilovi (ink/paper + signal #1e5eff)
  main.module.js    sva logika (kuća, overlayi, faze, forme, paralaks)
  build.py          build skripta — spaja src + lib u jedan index.html
lib/
  three.module.min.js / OrbitControls.module.js   three r165 (ES moduli)
  gsap.min.js / ScrollTrigger / ScrollToPlugin    GSAP 3.12.5
  lenis.min.js                                    Lenis 1.1.14
assets/
  favicon.png
  zmon-traced.svg   ZA monogram (trajani iz original logotipa)
  logo-light.png / logo-dark.png                  originalne verzije
```

## Build

```bash
python3 src/build.py
```

→ generira svjež `index.html` u rootu projekta.

## Publikacija na hosting

Dovoljno je uploadati **samo `index.html`** u root domene — nema vanjskih ovisnosti,
fontovi su ugrađeni (base64), sve biblioteke su inline.

## Najčešće prilagodbe

| Što | Gdje |
|---|---|
| Telefon / email adrese | `template.html` — traži `+385991234567` i `info@zaec.hr` |
| Cijene i paketi | `template.html`, sekcija `#cijene` |
| Tekstovi djelatnosti (tabovi) | `main.module.js` — polje `OCC` |
| 3D overlayi djelatnosti | `main.module.js` — `buildOverlays()` (0–7) |
| Forma (upit) | trenutno MOCK submit — u `main.module.js` nađi `inquiryForm`; spoji endpoint (Formspree / Netlify Forms ili vlastiti) |
| Brzina auto-playa tabova | `cycleMs()` — 4000 ms desktop / 5000 ms mobilno |
| Verzija | v4.6 (2026-08-10) |

**Što je novo u v4.4:** pročelje kuće s pravilnom kompozicijom (jedna vrata, poravnati prozori, balkonska vrata na katu), razvodi struje po svim zidovima, hotel bez figura i žutih svjetala (booking kartice ostaju), nova kartica proizvoda u shop overlayju, laptop kao radni kutak s mini-stranicom na ekranu, aksonometrija se centrira i povećava dok traje, paket "Landing po predlošku" (240 €), iskreniji copy bez obećanja prvog mjesta na Googleu, ažurirani brojevi (120+ / 5.0 / 21 / 100%), pregledniji potpis recenzija, mobilni layout forme i footera u stupcu.

**Što je novo u v4.5:** veći 3D viewport (72vh) — aksonometrija se više ne siječe gore/dolje i traje znatno duže; labele slojeva sada opisuju djelatnosti na kući (građevina, klima, voda, struja, krov...) umjesto naših usluga — one su pod "Web koji razumije vaš zanat"; scena procesa prati scroll (sticky popravljen); manji razmaci u sekciji cijena; potpisi recenzija kao svijetle "chip" oznake; jednaki brojevi u trust-traci (ispravljen CSS selektor); scroll bug na mobitelu preko 3D canvasa popravljen (touch-action).

**Što je novo u v4.6 (QA prolaz kroz pravi browser, 130+ automatskih provjera):** klik tabova djelatnosti radi i tijekom aksonometrije — izbor se odmah vidi na kartici, a overlay se prikaže čim se kuća sklopi; popravljen kritični CSS bug gdje je pravilo za tamne sekcije pretvaralo watermarkove i brojeve sekcija u vidljive elemente u tijeku stranice (prazan stupac kod forme, deformacije na mobitelu); site-footer dobio vlastitu klasu (njegovo tamno pravilo više ne propušta u potpise recenzija — "crna traka" nestala); mobitel: hero redoslijed copy → kuća → usluge vraćen; tabovi djelatnosti podignuti na rub 3D scene. Sve sekcije vizualno verificirane screenshotovima na 1440px i 390px.

## Bilješke

- Mobitel: bez pinned faza, sažeti FX, SVG fallback ako WebGL nije dostupan.
- `prefers-reduced-motion`: sve animacije miruju, sadržaj statičan ali potpun.
- Pristupačnost: skip-link, aria-labeli na 3D platnu, tabovi imaju `role="tab"`, tastatura ← → mijenja djelatnost, Space pauzira.
- SEO: Open Graph + JSON-LD (LocalBusiness + FAQPage) u `<head>`.

© 2026 ZAEC · obrt za računalne djelatnosti, vl. Filip Zajec, Osijek
