#!/usr/bin/env python3
"""ZAEC v3 build — sastavlja self-contained index.html.

Pipeline:
  - Google Fonts (Space Grotesk + IBM Plex Mono, latin + latin-ext) -> inline woff2 (base64)
  - styles.css -> inline
  - Three r165 ES module + OrbitControls -> importmap s data: URL-ovima (base64)
  - GSAP + ScrollTrigger + ScrollToPlugin + Lenis -> klasicne inline skripte
  - main.module.js -> inline <script type="module">
  - favicon + logo (light/dark) -> base64 PNG
"""
import base64
import json
import re
import sys
import urllib.request

ROOT = "/home/user/zaec"
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"}


def fetch(url, binary=False):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=40) as r:
        data = r.read()
    return data if binary else data.decode("utf-8")


def embed_urls(css):
    urls = sorted(set(re.findall(r"url\('?((?:https:)?//[^'\)]+\.woff2[^'\)]*)'?\)", css)))
    urls = [u if u.startswith("http") else "https:" + u for u in urls]
    out = css
    for u in urls:
        try:
            raw = fetch(u, binary=True)
            out = out.replace(u, "data:font/woff2;base64," + base64.b64encode(raw).decode("ascii"))
            print("    ok  %-44s %6.1f KB" % (u.split("/")[-1][:40], len(raw) / 1024))
        except Exception as e:
            print("    fail", u, e)
    return out


def google_fonts_subset(api):
    css = fetch(api)
    blocks = re.split(r"(?=/\* )", css)
    keep = [b for b in blocks if b.startswith("/* latin */") or b.startswith("/* latin-ext */")]
    print("  [fonts] subset blokova:", len(keep))
    return "\n".join(keep)


def build_fonts():
    try:
        css = google_fonts_subset(
            "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap")
        if "@font-face" not in css:
            raise ValueError("prazan CSS")
        return embed_urls(css)
    except Exception as e:
        print("  [fonts] neuspjeh:", e)
        return "/* fontovi nisu embedirani — fallback na system-ui */"


def b64_file(path, mime):
    raw = open(path, "rb").read()
    return "data:%s;base64,%s" % (mime, base64.b64encode(raw).decode("ascii"))


def js_data_url(path):
    """JS datoteka -> data:text/javascript URL (base64). Sigmoidno za </script jer je base64."""
    raw = open(path, "rb").read()
    return "data:text/javascript;base64," + base64.b64encode(raw).decode("ascii")


def build_importmap():
    mapping = {
        "imports": {
            "three": js_data_url(ROOT + "/lib/three.module.min.js"),
            "three/addons/controls/OrbitControls.js": js_data_url(ROOT + "/lib/OrbitControls.module.js"),
        }
    }
    print("  [importmap] three=%.0f KB, OrbitControls=%.0f KB (base64)" % (
        len(mapping["imports"]["three"]) / 1024, len(mapping["imports"]["three/addons/controls/OrbitControls.js"]) / 1024))
    return json.dumps(mapping, separators=(",", ":"))


def esc_js(code):
    """Sprijeci </script> unutar inline JS-a."""
    return code.replace("</script", "<\\/script")


def main():
    html = open(ROOT + "/src/template.html", encoding="utf-8").read()
    css = open(ROOT + "/src/styles.css", encoding="utf-8").read()
    mainjs = open(ROOT + "/src/main.module.js", encoding="utf-8").read()

    def lib(n):
        return open(ROOT + "/lib/" + n, encoding="utf-8").read()

    reps = [
        ("/*__IMPORTMAP__*/", build_importmap()),
        ("/*__INLINE_FONTS__*/", build_fonts()),
        ("/*__INLINE_CSS__*/", css),
        ("/*__INLINE_GSAP__*/", esc_js(lib("gsap.min.js"))),
        ("/*__INLINE_ST__*/", esc_js(lib("ScrollTrigger.min.js"))),
        ("/*__INLINE_SCROLLTO__*/", esc_js(lib("ScrollToPlugin.min.js"))),
        ("/*__INLINE_LENIS__*/", esc_js(lib("lenis.min.js"))),
        ("/*__INLINE_MAIN__*/", esc_js(mainjs)),
        ("__FAVICON__", b64_file(ROOT + "/assets/favicon.png", "image/png")),
        ("__LOGO_LIGHT__", b64_file(ROOT + "/assets/logo-light.png", "image/png")),
        ("__LOGO_DARK__", b64_file(ROOT + "/assets/logo-dark.png", "image/png")),
    ]
    for token, val in reps:
        if token not in html:
            print("  [info] token nije u predlosku (preskacem):", token)
            continue
        html = html.replace(token, val)

    left = re.findall(r"/\*__[A-Z_]+__\*/|__[A-Z_]+__", html)
    if left:
        print("  [FATAL] preostali tokeni:", sorted(set(left)))
        sys.exit(1)

    with open(ROOT + "/index.html", "w", encoding="utf-8") as f:
        f.write(html)
    kb = len(html.encode("utf-8")) / 1024
    print("index.html: %.1f KB (%.2f MB)" % (kb, kb / 1024))


if __name__ == "__main__":
    main()
