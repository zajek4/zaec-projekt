/* ============================================================
   ZAEC — main.js
   Linijski 3D nacrt kuće (aksonometrija), scrollytelling,
   blueprint scena, crosshair cursor, ruler, carousel, FAQ…
============================================================ */
(function () {
  'use strict';

  var doc = document;
  doc.documentElement.classList.add('js');

  var prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var isCoarse = window.matchMedia('(pointer: coarse)').matches;
  var mqDesktop = window.matchMedia('(min-width: 901px)');
  var STICKY = mqDesktop.matches && !prefersReducedMotion;
  if (STICKY) doc.documentElement.classList.add('sticky-on');
  if (prefersReducedMotion) doc.documentElement.classList.add('no-anim');

  function $(s, c) { return (c || doc).querySelector(s); }
  function $$(s, c) { return Array.prototype.slice.call((c || doc).querySelectorAll(s)); }
  function clamp(v, a, b) { return Math.min(b, Math.max(a, v)); }
  function lerp(a, b, t) { return a + (b - a) * t; }

  var gsapOK = typeof gsap !== 'undefined';
  var THREE_OK = typeof THREE !== 'undefined';
  if (gsapOK && typeof ScrollTrigger !== 'undefined') gsap.registerPlugin(ScrollTrigger);
  var ST_OK = gsapOK && typeof ScrollTrigger !== 'undefined';

  /* ============================================================
     0) PRELOADER
  ============================================================ */
  var heroReady = false;
  function startHero() {
    if (heroReady) return;
    heroReady = true;
    initHouseScene();
    if (!prefersReducedMotion && gsapOK) {
      gsap.to('.hero-block > *', { opacity: 1, y: 0, duration: 1, stagger: 0.09, ease: 'power3.out', delay: 0.15 });
      // brojači
      $$('.stat strong[data-count]').forEach(function (el) {
        var target = parseInt(el.getAttribute('data-count'), 10);
        gsap.to(el, { innerText: target, duration: 1.6, snap: { innerText: 1 }, ease: 'power2.out', delay: 0.5 });
      });
    } else {
      $$('.stat strong[data-count]').forEach(function (el) {
        el.textContent = el.getAttribute('data-count');
      });
    }
  }

  (function loader() {
    var el = $('#loader'), fill = $('#loaderFill'), pct = $('#loaderPct');
    if (!el) { startHero(); return; }
    if (prefersReducedMotion || !gsapOK) {
      el.style.display = 'none';
      startHero();
      return;
    }
    // hero sadržaj počinje skriven
    gsap.set('.hero-block > *', { opacity: 0, y: 26 });
    var state = { v: 0 };
    var loaded = doc.readyState === 'complete';
    window.addEventListener('load', function () { loaded = true; });
    gsap.to(state, {
      v: 100, duration: 1.6, ease: 'power2.inOut',
      onUpdate: function () {
        fill.style.width = state.v + '%';
        pct.textContent = ('00' + Math.round(state.v)).slice(-3);
      },
      onComplete: waitLoad
    });
    function waitLoad() {
      if (loaded || performance.now() > 5000) return finish();
      setTimeout(waitLoad, 80);
    }
    function finish() {
      gsap.to('.loader-inner', { opacity: 0, y: -20, duration: 0.4, ease: 'power2.in' });
      gsap.to(el, {
        yPercent: -100, duration: 0.8, ease: 'power4.inOut', delay: 0.25,
        onComplete: function () { el.style.display = 'none'; }
      });
      setTimeout(startHero, 500);
    }
  })();

  /* ============================================================
     1) CROSSHAIR CURSOR
  ============================================================ */
  (function crosshair() {
    if (isCoarse || prefersReducedMotion) return;
    var cur = $('#chCursor'); if (!cur) return;
    doc.body.classList.add('has-cursor');
    var label = $('#chLabel'), coords = $('#chCoords');
    var mx = -100, my = -100, cx = -100, cy = -100;
    doc.addEventListener('mousemove', function (e) {
      mx = e.clientX; my = e.clientY;
      coords.textContent = ('000' + mx).slice(-4) + ' : ' + ('000' + my).slice(-4);
    }, { passive: true });
    (function loop() {
      cx = lerp(cx, mx, 0.35); cy = lerp(cy, my, 0.35);
      cur.style.transform = 'translate(' + cx.toFixed(1) + 'px,' + cy.toFixed(1) + 'px)';
      requestAnimationFrame(loop);
    })();
    var hoverSel = 'a, button, input, select, textarea, [role="button"], .service-row, .faq-q, .work-card';
    doc.addEventListener('mouseover', function (e) {
      if (!e.target.closest) return;
      var inter = e.target.closest(hoverSel);
      cur.classList.toggle('is-hover', !!inter);
      cur.classList.toggle('is-cta', !!(inter && inter.closest('[data-ch]')));
    }, { passive: true });
  })();

  /* ============================================================
     2) NAV + SMOOTH SCROLL + body.on-dark
  ============================================================ */
  (function nav() {
    var nav = $('#siteNav'), burger = $('#hamburger'), menu = $('#mobileMenu');
    var open = false;
    function onScroll() { nav.classList.toggle('scrolled', window.scrollY > 24); }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    function setMenu(v) {
      open = v;
      menu.classList.toggle('open', v);
      menu.setAttribute('aria-hidden', String(!v));
      burger.setAttribute('aria-expanded', String(v));
      doc.body.style.overflow = v ? 'hidden' : '';
    }
    burger.addEventListener('click', function () { setMenu(!open); });
    doc.addEventListener('keydown', function (e) { if (e.key === 'Escape' && open) setMenu(false); });

    $$('a[data-scroll]').forEach(function (a) {
      a.addEventListener('click', function (e) {
        var id = a.getAttribute('href');
        if (!id || id[0] !== '#') return;
        var t = $(id); if (!t) return;
        e.preventDefault();
        setMenu(false);
        setTimeout(function () {
          // poseban slučaj: "Usluge" u sticky poglavlju → skrolaj u fazu usluga (~78% poglavlja)
          if (id === '#usluge' && STICKY) {
            var ch = $('#chapter');
            var y = ch.offsetTop + (ch.offsetHeight - window.innerHeight) * 0.78;
            window.scrollTo({ top: y, behavior: prefersReducedMotion ? 'auto' : 'smooth' });
            return;
          }
          t.scrollIntoView({ behavior: prefersReducedMotion ? 'auto' : 'smooth' });
        }, open ? 80 : 0);
      });
    });

    // on-dark kad je tamna sekcija pod vrhom (za nav i cursor)
    if ('IntersectionObserver' in window) {
      var darkVisible = 0;
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) { darkVisible += en.isIntersecting ? 1 : -1; });
        doc.body.classList.toggle('on-dark', darkVisible > 0);
      }, { rootMargin: '-45% 0px -45% 0px' });
      $$('.section-ink, .chapter, .site-footer').forEach(function (s) { io.observe(s); });
    }
  })();

  /* ============================================================
     3) REVEAL SUSTAV (GSAP + ScrollTrigger)
  ============================================================ */
  (function reveals() {
    if (!ST_OK || prefersReducedMotion) {
      $$('[data-reveal]').forEach(function (el) { el.style.opacity = 1; el.style.transform = 'none'; });
      return;
    }
    var inGroup = {};
    $$('[data-reveal-group]').forEach(function (group) {
      var kids = $$('[data-reveal]', group).filter(function (k) { return k !== group; });
      kids.forEach(function (k) { inGroup[k.id || (k.id = 'rg' + Math.random())] = 1; });
      ScrollTrigger.create({
        trigger: group, start: 'top 82%', once: true,
        onEnter: function () {
          gsap.to(kids, { opacity: 1, y: 0, duration: 0.9, stagger: 0.1, ease: 'power3.out', overwrite: true });
        }
      });
    });
    $$('[data-reveal]').forEach(function (el) {
      if (inGroup[el.id]) return;
      ScrollTrigger.create({
        trigger: el, start: 'top 85%', once: true,
        onEnter: function () { gsap.to(el, { opacity: 1, y: 0, duration: 0.9, ease: 'power3.out' }); }
      });
    });
    // plan-hot mali nagib naglaska
    var hot = $('.plan-hot');
    if (hot && window.innerWidth > 1080) gsap.to(hot, { y: -14, duration: 0.01, delay: 0.2 });
  })();

  /* ============================================================
     4) RULER — oznaka trenutne sekcije
  ============================================================ */
  (function ruler() {
    var marker = $('#rulerMarker'), num = $('#rulerNum');
    if (!marker) return;
    var secs = [
      ['chapter', '01'], ['poznato', '02'], ['nacrt', '03'], ['proces', '04'],
      ['cijene', '05'], ['radovi', '06'], ['klijenti', '07'], ['faq', '08'], ['upit', '09']
    ];
    if (!('IntersectionObserver' in window)) return;
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        for (var i = 0; i < secs.length; i++) {
          if (secs[i][0] === en.target.id) {
            num.textContent = secs[i][1];
            marker.style.top = (i / (secs.length - 1)) * 100 + '%';
          }
        }
      });
    }, { rootMargin: '-40% 0px -50% 0px' });
    secs.forEach(function (s) { var el = doc.getElementById(s[0]); if (el) io.observe(el); });
  })();

  /* ============================================================
     5) LINIJSKA KUĆA — graditelj (za hero i final scenu)
  ============================================================ */
  var JIT = 0.006; // "ručno" treperenje linija
  function j() { return (Math.random() - 0.5) * JIT; }

  // Skupi segmente u Float32Array parove
  function Seg() { this.pts = []; this.v = {}; }
  Seg.prototype.p = function (x, y, z) {
    var key = x.toFixed(3) + y.toFixed(3) + z.toFixed(3);
    if (!(key in this.v)) this.v[key] = true;
    this.pts.push(x + j(), y + j(), z + j());
  };
  Seg.prototype.line = function (a, b) { this.p(a[0], a[1], a[2]); this.p(b[0], b[1], b[2]); };
  Seg.prototype.box = function (cx, cy, cz, w, h, d) {
    var x0 = cx - w / 2, x1 = cx + w / 2, y0 = cy, y1 = cy + h, z0 = cz - d / 2, z1 = cz + d / 2;
    var c = [[x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1],
             [x0, y1, z0], [x1, y1, z0], [x1, y1, z1], [x0, y1, z1]];
    var e = [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]];
    for (var i = 0; i < e.length; i++) this.line(c[e[i][0]], c[e[i][1]]);
  };
  Seg.prototype.rectXY = function (cx, cy, cz, w, h) { // pravokutник u ravnini XY (oko cz)
    var x0 = cx - w / 2, x1 = cx + w / 2, y0 = cy, y1 = cy + h;
    this.line([x0, y0, cz], [x1, y0, cz]); this.line([x1, y0, cz], [x1, y1, cz]);
    this.line([x1, y1, cz], [x0, y1, cz]); this.line([x0, y1, cz], [x0, y0, cz]);
  };
  Seg.prototype.rectZY = function (cx, cy, cz, d, h) { // pravokutnik u ravnini ZY (oko cx)
    var z0 = cz - d / 2, z1 = cz + d / 2, y0 = cy, y1 = cy + h;
    this.line([cx, y0, z0], [cx, y0, z1]); this.line([cx, y0, z1], [cx, y1, z1]);
    this.line([cx, y1, z1], [cx, y1, z0]); this.line([cx, y1, z0], [cx, y0, z0]);
  };
  Seg.prototype.geometry = function () {
    var g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(this.pts), 3));
    return g;
  };

  function buildLineHouse(opt) {
    opt = opt || {};
    var lineColor = opt.color != null ? opt.color : 0xf4f4f1;
    var root = new THREE.Group();
    var groups = {}; // ime → {lines, glow, dir, count, anchor}
    var allNodes = [];

    function makeGroup(name, dir, anchor) {
      var g = new THREE.Group();
      g.userData.dir = dir;
      g.userData.name = name;
      root.add(g);
      groups[name] = { obj: g, anchor: anchor, baseOp: 0.0 };
      return g;
    }
    function fillGroup(name, seg) {
      var g = groups[name].obj;
      var geo = seg.geometry();
      var count = geo.attributes.position.count;
      var mat = new THREE.LineBasicMaterial({ color: lineColor, transparent: true, opacity: 0.92 });
      var lines = new THREE.LineSegments(geo, mat);
      var glowMat = new THREE.LineBasicMaterial({ color: 0x4d80ff, transparent: true, opacity: 0 });
      var glow = new THREE.LineSegments(geo, glowMat);
      glow.scale.set(1.004, 1.004, 1.004);
      g.add(lines); g.add(glow);
      groups[name].lines = lines; groups[name].glow = glow;
      groups[name].count = count;
      groups[name].drawObj = { p: 1 };
      // čvorovi
      var pos = geo.attributes.position.array;
      for (var i = 0; i < pos.length; i += 3) allNodes.push(pos[i] + g.position.x, pos[i + 1] + g.position.y, pos[i + 2] + g.position.z);
    }

    /* ---- PLOČA (temeljna ploča + parcele) ---- */
    var s = new Seg();
    s.box(0, -0.02, 0.2, 7.2, 0.06, 5.2);
    // kote parcele
    s.line([-3.6, 0.04, 2.8], [-3.4, 0.04, 2.8]); s.line([-3.5, -0.02, 2.7], [-3.5, 0.1, 2.9]);
    s.line([3.6, 0.04, -2.4], [3.4, 0.04, -2.4]); s.line([3.5, -0.02, -2.5], [3.5, 0.1, -2.3]);
    makeGroup('ploča', [0, -0.6, 0], new THREE.Vector3(0, 0, 1.6));
    fillGroup('ploča', s);

    /* ---- KONSTRUKCIJA (prizemlje + kat + aneks) ---- */
    s = new Seg();
    s.box(0, 0, 0, 3.6, 1.5, 2.6);          // prizemlje
    s.box(0, 1.5, 0, 3.6, 1.2, 2.6);         // kat
    s.box(-2.05, 0, 0.3, 1.1, 1.5, 1.9);     // lijevi aneks
    // međukatna linija
    s.line([-1.8, 1.5, 1.3], [1.8, 1.5, 1.3]);
    s.line([-1.8, 1.5, -1.3], [1.8, 1.5, -1.3]);
    // balkonska ploča na katu lijevo
    s.box(-2.6, 1.5, 0.85, 1.0, 0.06, 0.85);
    makeGroup('konstrukcija', [0, 0.3, 0], new THREE.Vector3(-1.2, 1.4, 1.3));
    fillGroup('konstrukcija', s);

    /* ---- STOLARIJA (prozori, vrata, ograda) ---- */
    s = new Seg();
    // prizemlje front
    s.rectXY(-0.95, 0.5, 1.302, 0.7, 0.65);
    s.rectXY(0.35, 0.5, 1.302, 0.55, 0.65);
    s.rectXY(1.05, 0.02, 1.302, 0.58, 1.1); // vrata
    s.line([1.05, 0.02, 1.303], [1.05, 1.12, 1.303]); // vertikala vrata
    // kat front
    s.rectXY(-1.1, 1.75, 1.302, 0.6, 0.6);
    s.rectXY(0, 1.75, 1.302, 0.6, 0.6);
    s.rectXY(1.1, 1.75, 1.302, 0.6, 0.6);
    // desna strana
    s.rectZY(1.802, 0.5, -0.6, 0.6, 0.65);
    s.rectZY(1.802, 0.5, 0.6, 0.6, 0.65);
    s.rectZY(1.802, 1.75, 0, 0.6, 0.6);
    // stražnja strana kat
    s.rectXY(-0.7, 1.75, -1.302, 0.6, 0.6);
    s.rectXY(0.7, 1.75, -1.302, 0.6, 0.6);
    // potkrovni prozorčić na zabatu
    s.rectZY(-1.81, 3.0, 0, 0.4, 0.4);
    // ograda balkona (gornja letva + vertikale)
    var bx0 = -3.1, bx1 = -2.1, bz0 = 0.42, bz1 = 1.28, railY = 2.42;
    s.line([bx0, railY, bz1], [bx1, railY, bz1]);
    s.line([bx0, railY, bz0], [bx0, railY, bz1]);
    s.line([bx1, railY, bz0], [bx1, railY, bz1]);
    for (var i = 0; i <= 8; i++) {
      var t = i / 8, rx = lerp(bx0, bx1, t);
      s.line([rx, 1.56, bz1], [rx, railY, bz1]);
    }
    for (i = 0; i <= 3; i++) {
      var t2 = i / 3, rz = lerp(bz0, bz1, t2);
      s.line([bx0, 1.56, rz], [bx0, railY, rz]);
    }
    makeGroup('stolarija', [0, 0.55, 0.85], new THREE.Vector3(0.4, 1.1, 1.3));
    fillGroup('stolarija', s);

    /* ---- TERASA (ploča + stolpići + nadstrešnica) ---- */
    s = new Seg();
    s.box(0, 0.03, 1.85, 4.0, 0.05, 1.0);       // ploča terase
    s.line([-1.7, 0, 2.25], [-1.7, 2.5, 2.25]); // stolpići
    s.line([1.7, 0, 2.25], [1.7, 2.5, 2.25]);
    s.line([0, 0, 2.25], [0, 2.5, 2.25]);
    s.line([-1.85, 2.5, 2.25], [1.85, 2.5, 2.25]); // letva nadstrešnice
    s.line([-1.85, 2.5, 1.3], [-1.85, 2.5, 2.35]);  // poprečne grede
    s.line([0, 2.5, 1.3], [0, 2.5, 2.35]);
    s.line([1.85, 2.5, 1.3], [1.85, 2.5, 2.35]);
    makeGroup('terasa', [0, 0.9, 1.7], new THREE.Vector3(1.6, 0.3, 2.3));
    fillGroup('terasa', s);

    /* ---- KROV (dvovodni + dimnjak) ---- */
    s = new Seg();
    var ridgeY = 4.0, eaveY = 2.7, rz = 0, ez = 1.6, rx = 2.1;
    // greben
    s.line([-rx, ridgeY, rz], [rx, ridgeY, rz]);
    // obije utore
    s.line([-rx, eaveY, ez], [rx, eaveY, ez]);
    s.line([-rx, eaveY, -ez], [rx, eaveY, -ez]);
    // zabati (trokuti na krajevima)
    s.line([-rx, eaveY, ez], [-rx, ridgeY, rz]); s.line([-rx, eaveY, -ez], [-rx, ridgeY, rz]);
    s.line([rx, eaveY, ez], [rx, ridgeY, rz]); s.line([rx, eaveY, -ez], [rx, ridgeY, rz]);
    s.line([-rx, eaveY, ez], [-rx, eaveY, -ez]);
    s.line([rx, eaveY, ez], [rx, eaveY, -ez]);
    // vetrovi (fascia) — kratke vertikale prema ploči krova
    s.line([-rx, eaveY, ez], [-rx, 2.55, ez]); s.line([rx, eaveY, ez], [rx, 2.55, ez]);
    s.line([-rx, eaveY, -ez], [-rx, 2.55, -ez]); s.line([rx, eaveY, -ez], [rx, 2.55, -ez]);
    // dvije rogve na prednjoj plohi (struktura krova)
    s.line([-0.7, ridgeY, rz], [-0.7, eaveY, ez]);
    s.line([0.7, ridgeY, rz], [0.7, eaveY, ez]);
    // dimnjak
    s.box(1.25, 3.35, -0.55, 0.36, 0.95, 0.36);
    s.box(1.25, 4.3, -0.55, 0.48, 0.09, 0.48);
    makeGroup('krov', [0, 2.15, 0], new THREE.Vector3(0.9, 4.0, -0.2));
    fillGroup('krov', s);

    /* ---- SVJETLARNICI (3 na prednjoj plohi krova) ---- */
    s = new Seg();
    // smjer niz kosinu: od grebena (y4.0,z0) do utore (y2.7,z1.6)
    function slopePoint(t, x) { return [x, 4.0 - t * 1.3, t * 1.6]; }
    for (var k = 0; k < 3; k++) {
      var cx = -1.15 + k * 1.15, ct = 0.55;
      var w2 = 0.3, l2 = 0.16; // poluširina po x, poluduljina niz kosinu (u t jedinicama)
      var a0 = slopePoint(ct - l2, cx - w2), a1 = slopePoint(ct - l2, cx + w2);
      var b0 = slopePoint(ct + l2, cx - w2), b1 = slopePoint(ct + l2, cx + w2);
      // malo podigni iznad plohe
      [a0, a1, b0, b1].forEach(function (p) { p[1] += 0.045; });
      s.line(a0, a1); s.line(a1, b1); s.line(b1, b0); s.line(b0, a0);
      // okvir
      var m = 0.045;
      var c0 = slopePoint(ct - l2 + m, cx - w2 + m), c1 = slopePoint(ct - l2 + m, cx + w2 - m);
      var d0 = slopePoint(ct + l2 - m, cx - w2 + m), d1 = slopePoint(ct + l2 - m, cx + w2 - m);
      [c0, c1, d0, d1].forEach(function (p) { p[1] += 0.05; });
      s.line(c0, c1); s.line(c1, d1); s.line(d1, d0); s.line(d0, c0);
    }
    makeGroup('svjetlarnici', [0, 2.95, 0.95], new THREE.Vector3(0, 3.72, 0.9));
    fillGroup('svjetlarnici', s);

    /* ---- ČVOROVI (mjerne točke) ---- */
    var nodesGeo = new THREE.BufferGeometry();
    nodesGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(allNodes), 3));
    var nodesMat = new THREE.PointsMaterial({ color: opt.nodeColor != null ? opt.nodeColor : 0x8f8f89, size: 2.4, sizeAttenuation: false, transparent: true, opacity: 0.65 });
    var nodes = new THREE.Points(nodesGeo, nodesMat);
    root.add(nodes);

    var order = ['ploča', 'konstrukcija', 'stolarija', 'terasa', 'krov', 'svjetlarnici'];
    return { root: root, groups: groups, order: order, nodes: nodes };
  }

  /* crtanje grupe: p 0..1 */
  function drawGroup(g, p) {
    var grp = g.lines;
    grp.geometry.setDrawRange(0, Math.floor(g.count * clamp(p, 0, 1) / 2) * 2);
  }

  /* ============ Generički renderer/scena wrapper ============ */
  var scenes = [];
  function makeScene(canvas, buildFn) {
    if (!THREE_OK || !canvas) return null;
    try {
      var renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true, alpha: true });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      renderer.setClearColor(0x000000, 0);
      var sc = { canvas: canvas, renderer: renderer, active: false, api: null };
      sc.api = buildFn(renderer, canvas);
      scenes.push(sc);
      if ('IntersectionObserver' in window) {
        new IntersectionObserver(function (en) { sc.active = en[0].isIntersecting; }, { threshold: 0 }).observe(canvas);
      } else sc.active = true;
      function onResize() {
        var w = canvas.clientWidth, h = canvas.clientHeight;
        if (!w || !h) return;
        renderer.setSize(w, h, false);
        if (sc.api && sc.api.camera) {
          if (sc.api.camera.isPerspectiveCamera) { sc.api.camera.aspect = w / h; }
          else if (sc.api.frustumH) {
            var asp = w / h, fh = sc.api.frustumH;
            sc.api.camera.left = -fh * asp / 2; sc.api.camera.right = fh * asp / 2;
          }
          sc.api.camera.updateProjectionMatrix();
        }
      }
      window.addEventListener('resize', onResize, { passive: true });
      onResize();
      return sc;
    } catch (e) { return null; }
  }

  /* ============================================================
     6) HERO SCENA + SCROLLYTELLING
  ============================================================ */
  var houseSceneInited = false;
  var houseApi = null;

  function initHouseScene() {
    if (houseSceneInited || !THREE_OK) return;
    houseSceneInited = true;
    var canvas = $('#houseCanvas');
    houseApi = makeScene(canvas, function (renderer) {
      var scene = new THREE.Scene();
      var camera = new THREE.PerspectiveCamera(38, 1, 0.1, 100);
      camera.position.set(6.4, 3.4, 8.6);
      camera.lookAt(0.2, 1.7, 0);

      var house = buildLineHouse({});
      var houseGroup = new THREE.Group();
      houseGroup.add(house.root);
      houseGroup.position.x = isMobileLayout() ? 0 : 1.3;
      houseGroup.position.y = -0.4;
      scene.add(houseGroup);

      var state = {
        explode: 0, targetExplode: 0,
        spin: 0, spinVel: 0.05,
        dragY: 0, dragX: 0, tDragY: 0, tDragX: 0,
        activePart: null,
        drawn: false
      };

      // Crtanje kuće na ulazu (grupa po grupa)
      if (!prefersReducedMotion && gsapOK) {
        house.order.forEach(function (name, i) {
          var g = house.groups[name];
          drawGroup(g, 0);
          gsap.to({ p: 0 }, {
            p: 1, duration: 0.9, delay: 0.25 + i * 0.22, ease: 'power2.inOut',
            onUpdate: function () { drawGroup(g, this.targets()[0].p); }
          });
        });
        gsap.from(house.nodes.material, { opacity: 0, duration: 1, delay: 1.6 });
      }

      // drag rotacija
      var dragging = false, px = 0, py = 0;
      canvas.addEventListener('pointerdown', function (e) { dragging = true; px = e.clientX; py = e.clientY; });
      window.addEventListener('pointermove', function (e) {
        if (!dragging) return;
        state.tDragY += (e.clientX - px) * 0.006;
        state.tDragX = clamp(state.tDragX + (e.clientY - py) * 0.003, -0.3, 0.5);
        px = e.clientX; py = e.clientY;
      }, { passive: true });
      window.addEventListener('pointerup', function () { dragging = false; });

      // miš parallax
      var mx = 0, my = 0;
      if (!isCoarse) window.addEventListener('mousemove', function (e) {
        mx = (e.clientX / window.innerWidth - 0.5);
        my = (e.clientY / window.innerHeight - 0.5);
      }, { passive: true });

      function applyExplode(f) {
        house.order.forEach(function (name) {
          var g = house.groups[name];
          var d = g.obj.userData.dir;
          g.obj.position.set(d[0] * f, d[1] * f, d[2] * f);
        });
      }

      var labelEls = {};
      $$('.part-label').forEach(function (el) { labelEls[el.getAttribute('data-part')] = el; });
      var v3 = new THREE.Vector3();

      function projectLabels() {
        if (!STICKY) return;
        house.order.forEach(function (name) {
          var g = house.groups[name];
          var el = labelEls[name];
          if (!el) return;
          if (state.showLabels < 0.02) { el.style.opacity = 0; return; }
          g.obj.updateWorldMatrix(true, false);
          v3.copy(g.anchor).applyMatrix4(g.obj.matrixWorld).project(camera);
          var x = (v3.x * 0.5 + 0.5) * canvas.clientWidth;
          var y = (-v3.y * 0.5 + 0.5) * canvas.clientHeight;
          el.style.transform = 'translate(' + x.toFixed(0) + 'px,' + (y - 8).toFixed(0) + 'px)';
          el.style.opacity = state.showLabels;
        });
      }

      state.showLabels = 0;

      var api = {
        camera: camera, state: state, house: house,
        setHighlight: function (part) {
          if (state.activePart === part) return;
          state.activePart = part;
          house.order.forEach(function (name) {
            var g = house.groups[name];
            var on = (part === name), dim = (part && !on);
            if (gsapOK) {
              gsap.to(g.glow.material, { opacity: on ? 1 : 0, duration: 0.4 });
              gsap.to(g.lines.material, { opacity: dim ? 0.18 : 0.92, duration: 0.4 });
              if (on) gsap.fromTo(g.glow.material, { opacity: 0.3 }, { opacity: 1, duration: 0.6 });
            } else {
              g.glow.material.opacity = on ? 1 : 0;
              g.lines.material.opacity = dim ? 0.18 : 0.92;
            }
          });
        },
        tick: function (dt) {
          state.explode = lerp(state.explode, state.targetExplode, 0.08);
          applyExplode(state.explode);
          state.dragY = lerp(state.dragY, state.tDragY, 0.1);
          state.dragX = lerp(state.dragX, state.tDragX, 0.1);
          state.spin += dt * state.spinVel;
          var baseX = 0.1 + state.dragX + my * 0.05;
          var rotY = state.spin + state.dragY + mx * 0.12;
          houseGroup.rotation.y = lerp(houseGroup.rotation.y, rotY, 0.06);
          houseGroup.rotation.x = lerp(houseGroup.rotation.x, baseX, 0.06);
          projectLabels();
          renderer.render(scene, camera);
        }
      };
      return api;
    });
  }

  function isMobileLayout() { return window.innerWidth < 901; }

  /* ---------- Scrollytelling scrub ---------- */
  function setupScrolly() {
    var caption = $('#phaseCaption');
    var heroBlock = $('#heroBlock');
    var services = $('#servicesList');
    var rows = $$('.service-row');
    var marketingNote = $('#marketingNote');
    var servicesBlock = $('#usluge');

    function setRow(i) {
      rows.forEach(function (r, k) { r.classList.toggle('is-active', k === i); });
      if (i >= 0 && houseApi && houseApi.api) houseApi.api.setHighlight(rows[i].getAttribute('data-part'));
      else if (houseApi && houseApi.api) houseApi.api.setHighlight(null);
    }

    if (!STICKY || !ST_OK) {
      // Statički mod: redovi su klikabilni za highlight
      rows.forEach(function (r) {
        r.addEventListener('pointerenter', function () {
          rows.forEach(function (x) { x.classList.remove('is-active'); });
          r.classList.add('is-active');
          if (houseApi && houseApi.api) houseApi.api.setHighlight(r.getAttribute('data-part'));
        });
      });
      return;
    }

    var lastRow = -1;

    ScrollTrigger.create({
      trigger: '#chapter',
      start: 'top top',
      end: 'bottom bottom',
      onUpdate: function (self) {
        var p = self.progress;
        if (!houseApi || !houseApi.api) return;
        var st = houseApi.api.state;

        // Faza A→B: hero out (0.16→0.30)
        var heroOut = clamp((p - 0.16) / 0.14, 0, 1);
        heroBlock.style.opacity = 1 - heroOut;
        heroBlock.style.transform = 'translateY(' + (-60 * heroOut) + 'px)';
        heroBlock.style.visibility = heroOut > 0.6 ? 'hidden' : '';

        // Eksplozija (0.28→0.55)
        st.targetExplode = clamp((p - 0.28) / 0.27, 0, 1);
        // Povratak u složeno dok čitamo usluge (0.70→0.86)
        if (p > 0.70) st.targetExplode = 1 - clamp((p - 0.70) / 0.16, 0, 1);
        st.spinVel = 0.05 + st.targetExplode * 0.05;

        // Naljepnice (0.36→0.62)
        st.showLabels = clamp((p - 0.36) / 0.08, 0, 1) * (1 - clamp((p - 0.58) / 0.05, 0, 1));
        caption.style.opacity = st.showLabels;

        // Faza C: usluge (0.66→1)
        var svcIn = clamp((p - 0.66) / 0.06, 0, 1);
        servicesBlock.style.opacity = svcIn;
        servicesBlock.classList.toggle('is-live', svcIn > 0.5);

        if (p > 0.70) {
          var idx = Math.floor((p - 0.70) / 0.27 * rows.length);
          idx = clamp(idx, 0, rows.length - 1);
          if (idx !== lastRow) { lastRow = idx; setRow(idx); }
        } else if (lastRow !== -1) { lastRow = -1; setRow(-1); }

        // Marketing nota na samom kraju
        var mn = clamp((p - 0.965) / 0.03, 0, 1);
        marketingNote.style.opacity = mn;
        if (mn > 0) servicesBlock.style.opacity = 1 - mn;
      }
    });
  }

  /* ============================================================
     7) BLUEPRINT SCENA — nacrt web stranice (scrub animacija)
  ============================================================ */
  function initBlueprint() {
    var canvas = $('#blueprintCanvas');
    if (!canvas) return;
    var captions = ['STRUKTURA — WIREFRAME 1:1', 'NAVIGACIJA', 'PORUKA', 'VIZUAL', 'POZIV NA AKCIJU', 'DOKAZ — LOGIKA KONVERZIJE'];
    var capEl = $('#bpCaptionText');

    makeScene(canvas, function (renderer) {
      var scene = new THREE.Scene();
      var camera = new THREE.PerspectiveCamera(36, 1, 0.1, 100);
      camera.position.set(0, 0, 9.2);

      var parts = []; // {lines, caption idx}
      function addLines(seg, blue) {
        var geo = seg.geometry();
        var mat = new THREE.LineBasicMaterial({ color: blue ? 0x4d80ff : 0xf4f4f1, transparent: true, opacity: blue ? 1 : 0.85 });
        var lines = new THREE.LineSegments(geo, mat);
        lines.userData.count = geo.attributes.position.count;
        geo.setDrawRange(0, 0);
        scene.add(lines);
        parts.push(lines);
        return lines;
      }

      // 1) okvir preglednika
      var s = new Seg();
      var W = 6.4, H = 4.0, bk = 24; // kut trake
      s.line([-W / 2, -H / 2, 0], [W / 2, -H / 2, 0]); s.line([W / 2, -H / 2, 0], [W / 2, H / 2 - 0.55, 0]);
      s.line([W / 2, H / 2 - 0.55, 0], [-W / 2, H / 2 - 0.55, 0]); s.line([-W / 2, H / 2 - 0.55, 0], [-W / 2, -H / 2, 0]);
      s.line([-W / 2, H / 2, 0], [W / 2, H / 2, 0]); s.line([W / 2, H / 2, 0], [W / 2, H / 2 - 0.55, 0]);
      s.line([-W / 2, H / 2, 0], [-W / 2, H / 2 - 0.55, 0]);
      // točkice + url
      s.rectXY(-W / 2 + 0.28, H / 2 - 0.38, 0, 0.09, 0.09); s.rectXY(-W / 2 + 0.52, H / 2 - 0.38, 0, 0.09, 0.09); s.rectXY(-W / 2 + 0.76, H / 2 - 0.38, 0, 0.09, 0.09);
      s.rectXY(-0.4, H / 2 - 0.47, 0, 3.6, 0.28);
      addLines(s);

      // 2) navigacija
      s = new Seg();
      s.rectXY(-2.55, 1.18, 0, 0.85, 0.34);
      for (var i = 0; i < 4; i++) s.rectXY(-0.8 + i * 0.85, 1.26, 0, 0.55, 0.1);
      s.rectXY(2.35, 1.14, 0, 1.0, 0.42);
      addLines(s);

      // 3) poruka (naslov + paragraf)
      s = new Seg();
      s.rectXY(-1.5, 0.62, 0, 2.7, 0.24);
      s.rectXY(-1.9, 0.26, 0, 1.9, 0.24);
      for (i = 0; i < 3; i++) s.rectXY(-2.0 - 0 * i, -0.06 - i * 0.22, 0, 2.4 - i * 0.35, 0.09);
      addLines(s);

      // 4) vizual (slika + dijagonale)
      s = new Seg();
      s.rectXY(1.95, -0.08, 0, 2.0, 1.35);
      s.line([1.95 - 1, -0.08, 0], [1.95 + 1, -0.08 + 1.35, 0]); // približno X
      s.line([1.95 + 1, -0.08, 0], [1.95 - 1, -0.08 + 1.35, 0]);
      s.rectXY(1.95, -0.08 + 1.35, 0, 2.0, 0); // osiguranje
      addLines(s);

      // 5) CTA — signal plava
      s = new Seg();
      s.rectXY(-2.0, -0.95, 0, 1.35, 0.5);
      s.rectXY(-2.0, -0.95, 0, 1.2, 0.36);
      var cta = addLines(s, true);

      // 6) 3 kartice (dokaz)
      s = new Seg();
      for (i = 0; i < 3; i++) {
        s.rectXY(-2.05 + i * 2.2, -1.78, 0, 1.85, 0.62);
        s.rectXY(-2.05 + i * 2.2 - 0.55, -1.6, 0, 0.7, 0.09);
        s.rectXY(-2.05 + i * 2.2 - 0.35, -1.86, 0, 1.1, 0.07);
      }
      addLines(s);

      // mrvice čvorova
      var ngeo = new THREE.BufferGeometry();
      var npos = [];
      parts.forEach(function (p) {
        var arr = p.geometry.attributes.position.array;
        for (var i = 0; i < arr.length; i += 3) npos.push(arr[i], arr[i + 1], arr[i + 2]);
      });
      ngeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(npos), 3));
      var nodes = new THREE.Points(ngeo, new THREE.PointsMaterial({ color: 0x8f8f89, size: 2, sizeAttenuation: false, transparent: true, opacity: 0 }));
      scene.add(nodes);

      var mx = 0, my = 0;
      if (!isCoarse) window.addEventListener('mousemove', function (e) {
        mx = (e.clientX / window.innerWidth - 0.5);
        my = (e.clientY / window.innerHeight - 0.5);
      }, { passive: true });

      var tlProgress = { v: 0 };
      function applyTL(v) {
        var n = parts.length;
        for (var i = 0; i < n; i++) {
          var local = clamp(v * (n + 0.5) - i * 0.82, 0, 1);
          var lines = parts[i];
          lines.geometry.setDrawRange(0, Math.floor(lines.userData.count * local / 2) * 2);
          if (capEl && local > 0.02 && local < 1) capEl.textContent = captions[Math.min(i, captions.length - 1)];
        }
        nodes.material.opacity = clamp((v - 0.85) / 0.15, 0, 0.55);
      }

      if (ST_OK && !prefersReducedMotion) {
        ScrollTrigger.create({
          trigger: '#nacrt', start: 'top 75%', end: 'center 45%', scrub: 0.6,
          onUpdate: function (self) { tlProgress.v = self.progress; applyTL(tlProgress.v); }
        });
      } else applyTL(1);

      return {
        camera: camera,
        tick: function (dt) {
          camera.position.x = lerp(camera.position.x, mx * 0.45, 0.05);
          camera.position.y = lerp(camera.position.y, -my * 0.35, 0.05);
          camera.lookAt(0, 0, 0);
          // CTA puls
          cta.material.opacity = 0.7 + Math.sin(performance.now() * 0.0035) * 0.3;
          renderer.render(scene, camera);
        }
      };
    });
  }

  /* ============================================================
     8) FINAL SCENA — kuća + mreža + kote
  ============================================================ */
  function initFinal() {
    var canvas = $('#finalCanvas');
    if (!canvas) return;
    makeScene(canvas, function (renderer) {
      var scene = new THREE.Scene();
      var camera = new THREE.PerspectiveCamera(40, 1, 0.1, 100);
      camera.position.set(7.4, 3.8, 9.4);
      camera.lookAt(0, 1.6, 0);

      var house = buildLineHouse({ color: 0xd9d9d4, nodeColor: 0x6f6f6a });
      house.root.position.y = 0;
      scene.add(house.root);

      var grid = new THREE.GridHelper(40, 40, 0x232320, 0x232320);
      grid.position.y = -0.06;
      grid.material.transparent = true;
      grid.material.opacity = 0.75;
      scene.add(grid);

      // kote (mjerne linije ispod kuće)
      var s = new Seg();
      s.line([-1.8, -0.04, 3.1], [1.8, -0.04, 3.1]);
      s.line([-1.8, -0.12, 3.02], [-1.8, 0.06, 3.18]); s.line([1.8, -0.12, 3.02], [1.8, 0.06, 3.18]);
      s.line([3.9, -0.04, -1.3], [3.9, -0.04, 1.3]);
      s.line([3.82, -0.12, -1.3], [3.98, 0.06, -1.3]); s.line([3.82, -0.12, 1.3], [3.98, 0.06, 1.3]);
      var dimGeo = s.geometry();
      var dims = new THREE.LineSegments(dimGeo, new THREE.LineBasicMaterial({ color: 0x4d80ff, transparent: true, opacity: 0.55 }));
      dims.position.y = 0;
      scene.add(dims);

      var spin = 0;
      return {
        camera: camera,
        tick: function (dt) {
          spin += dt * 0.055;
          house.root.rotation.y = spin;
          dims.rotation.y = spin;
          renderer.render(scene, camera);
        }
      };
    });
  }

  /* ============================================================
     9) GLOBALNI RAF LOOP
  ============================================================ */
  (function loop() {
    var last = performance.now();
    function frame(now) {
      var dt = Math.min(0.05, (now - last) / 1000); last = now;
      for (var i = 0; i < scenes.length; i++) {
        var sc = scenes[i];
        if (sc && sc.active && sc.api && sc.api.tick) {
          try { sc.api.tick(dt); } catch (e) { }
        }
      }
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  })();

  /* ============================================================
     10) STEPS — linija napretka + aktivni koraci
  ============================================================ */
  (function steps() {
    var fill = $('#stepsFill'), wrap = $('#steps');
    if (!wrap) return;
    window.addEventListener('scroll', function () {
      var r = wrap.getBoundingClientRect();
      var vh = window.innerHeight;
      var p = clamp((vh * 0.75 - r.top) / r.height, 0, 1);
      fill.style.transform = 'scaleY(' + p + ')';
    }, { passive: true });
    if ('IntersectionObserver' in window) {
      var io = new IntersectionObserver(function (ens) {
        ens.forEach(function (en) { en.target.classList.toggle('is-on', en.isIntersecting); });
      }, { threshold: 0.5 });
      $$('[data-step]').forEach(function (s) { io.observe(s); });
    }
  })();

  /* ============================================================
     11) QUOTES CAROUSEL
  ============================================================ */
  (function quotes() {
    var wrap = $('#quotes'); if (!wrap) return;
    var slides = $$('.quote'), dotsWrap = $('#qDots');
    var idx = 0, timer = null, busy = false;

    slides.forEach(function (_, i) {
      var d = doc.createElement('button');
      d.className = 'q-dot' + (i === 0 ? ' is-active' : '');
      d.setAttribute('aria-label', 'Izjava ' + (i + 1));
      d.addEventListener('click', function () { go(i, true); });
      dotsWrap.appendChild(d);
    });
    var dots = $$('.q-dot', dotsWrap);

    function go(n, manual) {
      if (busy || n === idx) return;
      var dir = n > idx ? 1 : -1;
      var old = slides[idx], cur = slides[n];
      idx = n;
      dots.forEach(function (d, i) { d.classList.toggle('is-active', i === idx); });
      if (!gsapOK || prefersReducedMotion) {
        old.classList.remove('is-active'); cur.classList.add('is-active');
        if (manual) restart();
        return;
      }
      busy = true;
      cur.classList.add('is-active');
      gsap.to(old, { opacity: 0, x: -40 * dir, duration: 0.35, ease: 'power2.in' });
      gsap.fromTo(cur, { opacity: 0, x: 60 * dir }, {
        opacity: 1, x: 0, duration: 0.5, delay: 0.22, ease: 'power3.out',
        onComplete: function () { old.classList.remove('is-active'); gsap.set(old, { clearProps: 'all' }); busy = false; }
      });
      if (manual) restart();
    }
    function next() { go((idx + 1) % slides.length); }
    function prev() { go((idx - 1 + slides.length) % slides.length); }
    function restart() { if (timer) clearInterval(timer); timer = setInterval(next, 6000); }
    $('#qNext').addEventListener('click', function () { next(); restart(); });
    $('#qPrev').addEventListener('click', function () { prev(); restart(); });
    wrap.addEventListener('mouseenter', function () { if (timer) clearInterval(timer); });
    wrap.addEventListener('mouseleave', restart);
    var sx = 0;
    wrap.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; }, { passive: true });
    wrap.addEventListener('touchend', function (e) {
      var dx = e.changedTouches[0].clientX - sx;
      if (Math.abs(dx) > 45) (dx < 0 ? next : prev)();
    }, { passive: true });
    restart();
  })();

  /* ============================================================
     12) FAQ
  ============================================================ */
  $$('.faq-item').forEach(function (item) {
    var btn = $('.faq-q', item), ans = $('.faq-a', item);
    if (!btn || !ans) return;
    btn.addEventListener('click', function () {
      var opening = !item.classList.contains('open');
      $$('.faq-item.open').forEach(function (other) {
        if (other === item) return;
        other.classList.remove('open');
        $('.faq-q', other).setAttribute('aria-expanded', 'false');
        var a = $('.faq-a', other);
        if (gsapOK && !prefersReducedMotion) gsap.to(a, { height: 0, duration: 0.4, ease: 'power2.inOut' });
        else a.style.height = '0px';
      });
      item.classList.toggle('open', opening);
      btn.setAttribute('aria-expanded', String(opening));
      if (opening) {
        if (gsapOK && !prefersReducedMotion) {
          gsap.fromTo(ans, { height: 0 }, { height: 'auto', duration: 0.5, ease: 'power2.inOut' });
        } else ans.style.height = 'auto';
      } else if (gsapOK && !prefersReducedMotion) {
        gsap.to(ans, { height: 0, duration: 0.35, ease: 'power2.inOut' });
      } else ans.style.height = '0px';
    });
  });

  /* ============================================================
     13) KONTAKT FORMA (upit)
  ============================================================ */
  (function form() {
    var form = $('#inquiryForm'); if (!form) return;
    var success = $('#inquirySuccess');

    $$('[data-package]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        $('#fPackage').value = btn.getAttribute('data-package');
        showToast('Odabran paket: ' + btn.getAttribute('data-package').toUpperCase() + ' — ostaje samo upit.');
      });
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var valid = true;
      $$('#inquiryForm [required]').forEach(function (f) {
        var wrap = f.closest('.field');
        wrap.classList.remove('field-error');
        if (!f.value.trim()) {
          wrap.classList.add('field-error'); valid = false;
          setTimeout(function () { wrap.classList.remove('field-error'); }, 1500);
        }
      });
      if (!valid) { showToast('Nedostaju obavezna polja — ime, kontakt i djelatnost.'); return; }

      var btn = $('.inq-submit', form), label = $('.submit-label', btn);
      btn.disabled = true;
      label.textContent = 'Šaljemo…';
      setTimeout(function () {
        form.hidden = true;
        success.hidden = false;
        if (gsapOK && !prefersReducedMotion) {
          gsap.from(success, { opacity: 0, y: 20, duration: 0.5, ease: 'power3.out' });
          gsap.to('.sd-frame', { strokeDashoffset: 0, duration: 0.8, ease: 'power2.inOut' });
          gsap.to('.sd-tick', { strokeDashoffset: 0, duration: 0.5, delay: 0.6, ease: 'power2.out' });
        } else {
          $('.sd-frame').style.strokeDashoffset = 0;
          $('.sd-tick').style.strokeDashoffset = 0;
        }
        showToast('Upit zaprimljen. Odgovor u roku 2 sata.');
      }, 900);
    });
  })();

  /* ============================================================
     14) TOAST
  ============================================================ */
  var toastEl = $('#toast'), toastT = null;
  function showToast(msg) {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.classList.add('visible');
    if (toastT) clearTimeout(toastT);
    toastT = setTimeout(function () { toastEl.classList.remove('visible'); }, 4000);
  }

  /* ============================================================
     15) MARQUEE — ubrzanje sa skrolanjem
  ============================================================ */
  (function marquee() {
    var track = $('#marqueeTrack'); if (!track || prefersReducedMotion) return;
    var lastY = window.scrollY, boost = 0;
    window.addEventListener('scroll', function () {
      boost = clamp(boost + Math.abs(window.scrollY - lastY) * 0.02, 0, 8);
      lastY = window.scrollY;
    }, { passive: true });
    (function tick() {
      boost = lerp(boost, 0, 0.06);
      track.style.animationDuration = (36 - clamp(boost, 0, 30)) + 's';
      requestAnimationFrame(tick);
    })();
  })();

  /* ============================================================
     INIT
  ============================================================ */
  function initAll() {
    initBlueprint();
    initFinal();
    setupScrolly();
  }
  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', initAll);
  else initAll();

  // hero scena ide tek nakon loadera (startHero); ali ako je loader prekriven
  setTimeout(function () { startHero(); }, prefersReducedMotion ? 400 : 2600);

})();
