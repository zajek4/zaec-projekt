<?php
/**
 * ZAEC front page.
 *
 * @package ZAEC
 */
get_header();
?>
<main id="main">
<?php
foreach ( array( 'hero-network', 'hero', 'marquee', 'poznato', 'metoda', 'proces', 'ekran', 'cijene', 'radovi', 'studio', 'testimonials', 'faq', 'contact' ) as $part ) {
	get_template_part( 'template-parts/front-page/' . $part );
}
?>
</main>
<?php get_footer(); ?>
