<?php
/**
 * Small, safe content-model migrations between ZAEC theme revisions.
 *
 * Migrations only replace values that still exactly match a known previous
 * default. Client edits are never overwritten.
 *
 * @package ZAEC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function zaec_migrate_theme_data() {
	$version  = (string) get_option( 'zaec_theme_data_version', '1.0.0' );
	$front_id = (int) get_option( 'page_on_front' );

	if ( $front_id && version_compare( $version, '1.1.0', '<' ) ) {
		$defaults  = zaec_front_defaults();
		$repeaters = zaec_front_repeater_defaults();
		$pricing   = get_post_meta( $front_id, '_zaec_pricing', true );

		// Old 1.0 pricing rows had no `track` key. Migrate only that known shape.
		if ( is_array( $pricing ) && ! empty( $pricing ) && ! array_key_exists( 'track', $pricing[0] ) ) {
			update_post_meta( $front_id, '_zaec_pricing', $repeaters['pricing'] );
		}
		if ( ! get_post_meta( $front_id, '_zaec_pricing_notes', true ) ) {
			update_post_meta( $front_id, '_zaec_pricing_notes', $repeaters['pricing_notes'] );
		}

		$known_old = array(
			'cijene_title'    => 'Cijena kao u građevini: dogovorena unaprijed.',
			'cijene_lead'     => 'Tri paketa i brza varijanta po predlošku — sve fiksne cijene. Ako nešto poskupi u tijeku posla, to je naš problem, ne vaš.',
			'band_kicker'     => 'Najbrža opcija',
			'band_title'      => 'Landing po predlošku.',
			'band_text'       => 'Odaberete jedan od 12 provjerenih predložaka, mi ugradimo vaš sadržaj, boje i logo — bez čekanja na nacrt. Cijena je poznata odmah i ne miče se.',
			'band_price'      => '240 €',
			'band_price_meta' => 'jednokratno',
			'band_cta'        => 'Zanima me predložak',
		);
		foreach ( $known_old as $key => $old_value ) {
			$current = get_post_meta( $front_id, '_zaec_' . $key, true );
			if ( '' === $current || $old_value === $current ) {
				update_post_meta( $front_id, '_zaec_' . $key, $defaults[ $key ] );
			}
		}
	}

	if ( $front_id && version_compare( $version, '1.2.0', '<' ) ) {
		$repeaters = zaec_front_repeater_defaults();
		$defaults  = zaec_front_defaults();

		$old_occupations = array(
			array( 'tab' => 'Klima', 'title' => 'Za klimatizaciju', 'sub' => 'Servis, ugradnja, čišćenje — vaš klijent traži baš vas.', 'q' => 'Najčešći Google upit: "klima servis + grad"' ),
			array( 'tab' => 'Voda', 'title' => 'Za vodoinstalatere', 'sub' => 'Popravci, adaptacije, hitne intervencije — 0-24.', 'q' => 'Najčešći Google upit: "vodoinstalater hitno"' ),
			array( 'tab' => 'Struja', 'title' => 'Za električare', 'sub' => 'Instalacije, popravci, atesti — posao ide njemu tko se vidi.', 'q' => 'Najčešći Google upit: "električar + grad"' ),
			array( 'tab' => 'Krov', 'title' => 'Za krovopokrivače i limare', 'sub' => 'Sanacije, nove izvedbe, rekonstrukcije — sezona traje kratko.', 'q' => 'Najčešći Google upit: "krovopokrivač Osijek"' ),
			array( 'tab' => 'Građevina', 'title' => 'Za građevinare', 'sub' => 'Novogradnja i adaptacije, od temelja do krova — posao ide onom tko izgleda ozbiljno.', 'q' => 'Najčešći Google upit: "građevinar + adaptacija"' ),
			array( 'tab' => 'Hotel', 'title' => 'Za hotele i smještaj', 'sub' => 'Sobe, termini, gosti — direktne rezervacije bez provizija bookinga.', 'q' => 'Najčešći Google upit: "apartmani + grad + booking"' ),
			array( 'tab' => 'Shop', 'title' => 'Za trgovine i webshopove', 'sub' => 'Prodaja online 0-24 — vaš dućan ne zatvara vrata.', 'q' => 'Najčešći Google upit: "kupiti + proizvod + dostava"' ),
			array( 'tab' => '+', 'title' => 'Za sve ostale', 'sub' => 'Odvjetnik, računovođa, terapeut, škola — svima treba dom online.', 'q' => 'Web stranica je vaša digitalna vizit-karta.' ),
		);
		$current_occupations = get_post_meta( $front_id, '_zaec_occupations', true );
		if ( is_array( $current_occupations ) && $old_occupations === $current_occupations ) {
			update_post_meta( $front_id, '_zaec_occupations', $repeaters['occupations'] );
		}

		$old_process = array(
			array( 'code' => 'K.01', 'title' => 'Razgovor', 'text' => 'Poziv od 20 minuta. Saslušamo, posavjetujemo — i pošteno kažemo što vam se isplati: predložak ili izrada po mjeri.', 'meta' => '20 min · besplatno' ),
			array( 'code' => 'K.02', 'title' => 'Smjer i opseg', 'text' => 'Kod predloška biramo postojeći smjer. Kod izrade po mjeri prvo crtamo nacrt. U oba slučaja opseg potvrđujemo prije razvoja.', 'meta' => 'predložak ili nacrt · opseg potvrđen' ),
			array( 'code' => 'K.03', 'title' => 'Izgradnja', 'text' => 'WordPress, responsive izvedba i testiranje prema odobrenom opsegu.', 'meta' => 'rok prema opsegu · bez otvorenog scopea' ),
			array( 'code' => 'K.04', 'title' => 'Objava i primopredaja', 'text' => 'Objava, pristupi i kratka primopredaja. Nakon toga slijedi tehničko jamstvo za isporučeni rad.', 'meta' => '14 dana tehničkog jamstva' ),
		);
		$current_process = get_post_meta( $front_id, '_zaec_process_steps', true );
		if ( is_array( $current_process ) && $old_process === $current_process ) {
			update_post_meta( $front_id, '_zaec_process_steps', $repeaters['process_steps'] );
		}

		$old_screen_points = array(
			array( 'code' => '5.1', 'title' => 'Dizajnirano za palac', 'text' => 'Svaki gumb, svaka slika i svaki redak prvo stane na mali ekran — bez štipanja i zumiranja.' ),
			array( 'code' => '5.2', 'title' => 'Poziv u jednom dodirom', 'text' => 'Vaš broj prikovan za dno ekrana — klijent ne traži, nego zove.' ),
			array( 'code' => '5.3', 'title' => 'Brže od kave', 'text' => 'Cilj je učitavanje ispod 2 sekunde i na slabijem signalu. Google to nagradi, klijent ostane.' ),
		);
		$current_screen_points = get_post_meta( $front_id, '_zaec_screen_points', true );
		if ( is_array( $current_screen_points ) && $old_screen_points === $current_screen_points ) {
			update_post_meta( $front_id, '_zaec_screen_points', $repeaters['screen_points'] );
		}

		$old_screen_lead = 'Više od polovice upita dolazi s mobitela — iz kombija, s gradilišta, s kauča. Zato svaku stranicu prvo gradimo za mali ekran, pa tek onda za veliki stolni.';
		$current_screen_lead = get_post_meta( $front_id, '_zaec_ekran_lead', true );
		if ( $old_screen_lead === $current_screen_lead ) {
			update_post_meta( $front_id, '_zaec_ekran_lead', $defaults['ekran_lead'] );
		}

		$old_testimonials = array(
			array( 'quote' => 'Tražio sam nešto kao za velike firme, ali normalne cijene. Dobio točno to. Troje ljudi mi se javilo već prvi tjedan.', 'name' => 'Marko Kovač', 'role' => 'Klimatizacija', 'company' => 'Zagreb' ),
			array( 'quote' => 'Poslao sam slike s mobitela i za tjedan dana imao stranicu. Da je ovako lako, napravio bih prije pet godina.', 'name' => 'Ivan Perić', 'role' => 'Vodoinstalacije', 'company' => 'Split' ),
			array( 'quote' => 'Najviše mi znači što mi je sve objašnjeno ljudski, bez stranih riječi. Gosti sad rezerviraju direktno — bez provizija.', 'name' => 'Petra Babić', 'role' => 'Pansion', 'company' => 'Zadar' ),
			array( 'quote' => 'Konkurencija me nedavno pitala tko mi radi web. Nisam rekao.', 'name' => 'Josip Horvat', 'role' => 'Krovopokrivač', 'company' => 'Osijek' ),
		);
		$current_testimonials = get_post_meta( $front_id, '_zaec_testimonials', true );
		if ( is_array( $current_testimonials ) && $old_testimonials === $current_testimonials ) {
			delete_post_meta( $front_id, '_zaec_testimonials' );
		}
	}

	if ( version_compare( $version, '1.2.0', '<' ) ) {
		update_option( 'zaec_theme_data_version', '1.2.0', false );
	}

	// v1.3 — kontakt, pravni podaci, FAQ omekšavanje samo ako još stoji stari default.
	if ( version_compare( $version, '1.3.0', '<' ) ) {
		$opts = get_option( 'zaec_options', array() );
		if ( ! is_array( $opts ) ) {
			$opts = array();
		}
		$opt_defaults = zaec_options_defaults();
		// Demo telefon → produkcijski samo ako je ostao factory demo.
		if ( empty( $opts['phone_display'] ) || '099 123 4567' === $opts['phone_display'] ) {
			$opts['phone_display'] = $opt_defaults['phone_display'];
			$opts['phone_raw']     = $opt_defaults['phone_raw'];
		}
		if ( empty( $opts['form_recipient'] ) || get_option( 'admin_email' ) === $opts['form_recipient'] ) {
			$opts['form_recipient'] = $opt_defaults['form_recipient'];
		}
		// Makni javni demo email ako je ostao.
		if ( isset( $opts['email'] ) && in_array( $opts['email'], array( 'info@zaec.hr', '' ), true ) ) {
			$opts['email'] = '';
			$opts['show_public_email'] = '0';
		}
		foreach ( array( 'mb', 'owner_name', 'postal_code', 'nkd', 'address', 'legal_name' ) as $k ) {
			if ( empty( $opts[ $k ] ) && ! empty( $opt_defaults[ $k ] ) ) {
				$opts[ $k ] = $opt_defaults[ $k ];
			}
		}
		if ( empty( $opts['show_public_email'] ) ) {
			$opts['show_public_email'] = '0';
		}
		update_option( 'zaec_options', $opts, false );

		if ( $front_id ) {
			$old_city_faq_q = 'Zašto ste iz Osijeka a radite za cijelu Hrvatsku?';
			$faqs = get_post_meta( $front_id, '_zaec_faqs', true );
			if ( is_array( $faqs ) ) {
				$changed = false;
				foreach ( $faqs as $i => $faq ) {
					if ( isset( $faq['question'] ) && $old_city_faq_q === $faq['question'] ) {
						$faqs[ $i ] = array(
							'question' => 'Radite li samo lokalno ili za cijelu Hrvatsku?',
							'answer'   => 'Sjedište je u Osijeku, a projekte vodimo za klijente diljem Hrvatske — uživo kad ima smisla, inače video-pozivom i jasnim pisanim dogovorom. Radili smo s obrtnicima i s većim tvrtkama, uključujući suradnje na daljinu s klijentima izvan Hrvatske kad opseg to traži.',
						);
						$changed = true;
					}
				}
				if ( $changed ) {
					update_post_meta( $front_id, '_zaec_faqs', $faqs );
				}
			}
		}

		update_option( 'zaec_theme_data_version', '1.3.0', false );
	}

	if ( version_compare( $version, '1.3.1', '<' ) ) {
		if ( $front_id ) {
			$old_plus = array(
				'tab'   => '+',
				'title' => 'Za druge uslužne djelatnosti',
				'sub'   => 'Ako kupci prije odluke stalno postavljaju ista pitanja, web ih može odgovoriti prije prvog poziva.',
				'q'     => 'Na webu: struktura prema vašem načinu prodaje — bez generičkog paketa',
			);
			$occ = get_post_meta( $front_id, '_zaec_occupations', true );
			if ( is_array( $occ ) ) {
				foreach ( $occ as $i => $row ) {
					if ( is_array( $row ) && isset( $row['title'], $row['sub'] ) && $row['title'] === $old_plus['title'] && $row['sub'] === $old_plus['sub'] ) {
						$occ[ $i ] = array(
							'tab'   => '+',
							'title' => 'Za ostale usluge i struke',
							'sub'   => 'Odvjetnik, računovođa, ordinacija, studio, škola… Ako klijenti prije odluke uvijek pitaju isto, stranica može dati jasan odgovor i uputiti na poziv ili upit.',
							'q'     => 'Na webu: usluge · cijene/okvir · FAQ · jasan CTA — bez generičkog paketa',
						);
					}
				}
				update_post_meta( $front_id, '_zaec_occupations', $occ );
			}
		}
		update_option( 'zaec_theme_data_version', '1.3.1', false );
	}

	if ( version_compare( $version, '1.3.4', '<' ) ) {
		if ( $front_id ) {
			$stats = get_post_meta( $front_id, '_zaec_hero_stats', true );
			$old_two = array(
				array( 'count' => '2', 'suffix' => '', 'label' => 'načina izrade' ),
				array( 'count' => '1', 'suffix' => '', 'label' => 'cijena prije koda' ),
			);
			if ( is_array( $stats ) && $stats === $old_two ) {
				update_post_meta( $front_id, '_zaec_hero_stats', zaec_front_repeater_defaults()['hero_stats'] );
			}
			$lead = get_post_meta( $front_id, '_zaec_hero_lead', true );
			$old_leads = array(
				'WordPress i landing pageovi — po predlošku ili po nacrtu. Za obrte i tvrtke diljem Hrvatske. Opseg i cijena prije početka.',
				'WordPress stranice, landingi i Google prisutnost — po predlošku ili po nacrtu. Radimo s obrtima i tvrtkama u Hrvatskoj, a po potrebi i na daljinu s klijentima izvan nje. Opseg i cijenu dogovorimo prije početka.',
			);
			if ( in_array( $lead, $old_leads, true ) ) {
				update_post_meta( $front_id, '_zaec_hero_lead', zaec_front_defaults()['hero_lead'] );
			}
		}
		update_option( 'zaec_theme_data_version', '1.3.4', false );
	}

	if ( version_compare( $version, '1.3.5', '<' ) ) {
		if ( $front_id ) {
			// Hero stats uklonjeni s UI-ja — obriši meta da se ne vraćaju.
			delete_post_meta( $front_id, '_zaec_hero_stats' );
			$lead = get_post_meta( $front_id, '_zaec_hero_lead', true );
			if ( is_string( $lead ) && false !== strpos( $lead, '10+ godina na webu, 8 na WordPressu' ) ) {
				update_post_meta( $front_id, '_zaec_hero_lead', zaec_front_defaults()['hero_lead'] );
			}
		}
		update_option( 'zaec_theme_data_version', '1.3.5', false );
	}
}
add_action( 'admin_init', 'zaec_migrate_theme_data' );
